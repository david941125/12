import json
import os
from datetime import datetime

FILE_PATH = "expenses.json"
BUDGET_PATH = "budget.json"

# ---------- 資料處理 ----------
def load_data(file_path):
    if not os.path.exists(file_path):
        return {}
    with open(file_path, "r", encoding="utf-8") as f:
        return json.load(f)

def save_data(data, file_path):
    with open(file_path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

# ---------- 新增與顯示 ----------
def add_expense():
    date = input("輸入日期（YYYY-MM-DD）：")
    try:
        datetime.strptime(date, "%Y-%m-%d")
    except ValueError:
        print("日期格式錯誤。")
        return None
    try:
        amount = float(input("輸入金額："))
    except ValueError:
        print("金額格式錯誤，請輸入數字。")
        return None
    category = input("輸入類別（如 餐飲、交通）：")
    note = input("備註：")
    return {"date": date, "amount": amount, "category": category, "note": note}

def display_expenses(expenses):
    if not expenses:
        print("目前沒有任何紀錄。")
        return
    print("\n所有花費紀錄：")
    for i, item in enumerate(expenses, start=1):
        print(f"{i}. {item['date']} - {item['category']} - ${item['amount']} - {item['note']}")

# ---------- 查詢 ----------
def search_expenses(expenses):
    keyword = input("請輸入要搜尋的關鍵字：")
    results = [e for e in expenses if keyword in e["date"] or keyword in e["category"] or keyword in e["note"]]
    if not results:
        print("沒有符合的紀錄。")
    else:
        for i, item in enumerate(results, start=1):
            print(f"{i}. {item['date']} - {item['category']} - ${item['amount']} - {item['note']}")

# ---------- 預算檢查 ----------
def check_budget(expenses, budget):
    print("\n📢 預算提醒：")
    if budget.get("monthly") is not None:
        print(f"🗓️ 每月預算剩餘：${budget['monthly']:.2f}")
        if budget['monthly'] < 0:
            print("⚠️ 本月預算已超支！")
    if budget.get("weekly") is not None:
        print(f"🗓️ 每週預算剩餘：${budget['weekly']:.2f}")
        if budget['weekly'] < 0:
            print("⚠️ 本週預算已超支！")

# ---------- 刪除與編輯 ----------
def delete_expense(expenses, budget):
    display_expenses(expenses)
    try:
        idx = int(input("要刪除哪一筆？輸入編號：")) - 1
        if 0 <= idx < len(expenses):
            removed = expenses.pop(idx)
            if budget.get("monthly") is not None:
                budget["monthly"] += removed["amount"]
            if budget.get("weekly") is not None:
                budget["weekly"] += removed["amount"]
            print("已刪除。")
        else:
            print("編號錯誤。")
    except ValueError:
        print("請輸入數字。")

def edit_expense(expenses, budget):
    display_expenses(expenses)
    try:
        idx = int(input("要修改哪一筆？輸入編號：")) - 1
        if 0 <= idx < len(expenses):
            old = expenses[idx]
            if budget.get("monthly") is not None:
                budget["monthly"] += old["amount"]
            if budget.get("weekly") is not None:
                budget["weekly"] += old["amount"]
            print("輸入新資料（可留空跳過）：")
            date = input(f"日期（{old['date']}）：") or old["date"]
            amount = input(f"金額（{old['amount']}）：")
            amount = float(amount) if amount else old["amount"]
            category = input(f"類別（{old['category']}）：") or old["category"]
            note = input(f"備註（{old['note']}）：") or old["note"]
            expenses[idx] = {"date": date, "amount": amount, "category": category, "note": note}
            if budget.get("monthly") is not None:
                budget["monthly"] -= amount
            if budget.get("weekly") is not None:
                budget["weekly"] -= amount
            print("已修改。")
        else:
            print("編號錯誤。")
    except ValueError:
        print("金額格式錯誤。")

# ---------- 預算功能 ----------
def set_budget(budget):
    try:
        monthly = float(input("設定每月預算：") or 0)
        weekly = float(input("設定每週預算：") or 0)
        budget["monthly"] = monthly if monthly else None
        budget["weekly"] = weekly if weekly else None
        print("預算設定完成！")
    except ValueError:
        print("請輸入正確數字。")

def view_budget(budget):
    print("\n📊 目前預算狀況：")
    if budget.get("monthly") is not None:
        print(f"每月預算剩餘：${budget['monthly']:.2f}")
    else:
        print("每月預算：未設定")
    if budget.get("weekly") is not None:
        print(f"每週預算剩餘：${budget['weekly']:.2f}")
    else:
        print("每週預算：未設定")

def delete_budget(budget):
    confirm = input("確定刪除預算？(y/n)：")
    if confirm.lower() == "y":
        budget.clear()
        print("已刪除預算設定。")

# ---------- 主程式 ----------
def main():
    expenses = load_data(FILE_PATH)
    if not isinstance(expenses, list):
        expenses = []
    budget = load_data(BUDGET_PATH)
    if not isinstance(budget, dict):
        budget = {}

    while True:
        print("\n=== 每日記帳系統 ===")
        print("1. 花費紀錄管理")
        print("2. 預算管理")
        print("3. 離開")
        main_choice = input("請輸入選項（1-3）：")

        if main_choice == "1":
            while True:
                print("\n--- 花費紀錄管理 ---")
                print("1. 新增花費")
                print("2. 查看紀錄")
                print("3. 修改花費")
                print("4. 刪除花費")
                print("5. 搜尋花費")
                print("6. 返回")
                sub_choice = input("請輸入選項（1-6）：")
                if sub_choice == "1":
                    new = add_expense()
                    if new:
                        expenses.append(new)
                        save_data(expenses, FILE_PATH)
                        if budget.get("monthly") is not None:
                            budget["monthly"] -= new["amount"]
                        if budget.get("weekly") is not None:
                            budget["weekly"] -= new["amount"]
                        save_data(budget, BUDGET_PATH)
                        check_budget(expenses, budget)
                elif sub_choice == "2":
                    display_expenses(expenses)
                elif sub_choice == "3":
                    edit_expense(expenses, budget)
                    save_data(expenses, FILE_PATH)
                    save_data(budget, BUDGET_PATH)
                elif sub_choice == "4":
                    delete_expense(expenses, budget)
                    save_data(expenses, FILE_PATH)
                    save_data(budget, BUDGET_PATH)
                elif sub_choice == "5":
                    search_expenses(expenses)
                elif sub_choice == "6":
                    break
                else:
                    print("選項錯誤。")
        elif main_choice == "2":
            while True:
                print("\n--- 預算管理 ---")
                print("1. 設定預算")
                print("2. 查看預算")
                print("3. 刪除預算")
                print("4. 返回")
                b = input("請輸入選項（1-4）：")
                if b == "1":
                    set_budget(budget)
                    save_data(budget, BUDGET_PATH)
                elif b == "2":
                    view_budget(budget)
                elif b == "3":
                    delete_budget(budget)
                    save_data(budget, BUDGET_PATH)
                elif b == "4":
                    break
                else:
                    print("選項錯誤。")
        elif main_choice == "3":
            print("再見！")
            break
        else:
            print("無效選項。")

if __name__ == "__main__":
    main()